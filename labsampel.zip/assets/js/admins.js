function edit_admin(id){
    // console.log(id);
    $('#editModal').modal('show');
    $('#edit_form').html("<center>Tunggu Sebentar...</center>");
    $('#edit_form').load('components/edit_admins.php?id=' + id);
};
function hapus_admin(id,id1){
    console.log(id,id1);
    if(id != id1){
        $.ajax({
            type: "POST",
            url: "../controllers/crudAdmins.php",
            data: {
                dataDelete:id
            },
            dataType: 'json',
            success: function(response) {
                        console.log(response);
                        swal('Data Terdelete', {
                            icon : "success",
                            buttons: {
                                confirm: {
                                    className : 'btn btn-success'
                                }
                            },
                        }).then((Oke) => {
                            if (Oke) {
                                location.reload();
                            }
                        });
            },
            error: function(response) {
                        console.log(response);
                        swal('Gagal Terdelete', {
                            buttons: {
                                confirm: {
                                    className : 'btn btn-warning'
                                }
                            },
                        }).then((Oke) => {
                            if (Oke) {
                                location.reload();
                            }
                        });
            }
        });
    }else{
        swal("Error", "Tidak boleh delete akun sendiri", {
            icon : "error",
            buttons: {
                confirm: {
                    className : 'btn btn-danger'
                }
            },
        });
        
    }
}

$('.tambah').click(function(){
    var namatambah = $("#nama_userstambah").val();
    var usernametambah = $("#usernametambah").val();
    var passwordtambah = $("#passwordtambah").val();
    // console.log(nama,username,password);
    $.ajax({
        type: "POST",
        url: "../controllers/crudAdmins.php",
        data: {
            dataTambah:[usernametambah,namatambah,passwordtambah]
        },
        dataType: 'json',
        success: function(response) {
                    console.log(response);
                    if(response == 0){
                        swal('Gagal Tertambah', 'Username sudah terdaftar', {
                            buttons: {
                                confirm: {
                                    className : 'btn btn-warning'
                                }
                            },
                        });
                    }else{
                        swal('Data Tertambah', {
                            icon : "success",
                            buttons: {
                                confirm: {
                                    className : 'btn btn-success'
                                }
                            },
                        }).then((Oke) => {
                            if (Oke) {
                                location.reload();
                            }
                        });
                    }
        },
        error: function(response) {
                    console.log(response);
                    swal('Gagal Terupdate', {
                        buttons: {
                            confirm: {
                                className : 'btn btn-warning'
                            }
                        },
                    }).then((Oke) => {
                        if (Oke) {
                            location.reload();
                        }
                    });
        }
    });
});

$('.updatee').click(function(){
    var namaupdatee = $("#nama_usersupdatee").val();
    var id_usersupdatee = $("#id_usersupdatee").val();
    var passwordupdatee = $("#passwordupdatee").val();
    $.ajax({
        type: "POST",
        url: "../controllers/crudAdmins.php",
        data: {
            dataEdit:[id_usersupdatee,namaupdatee,passwordupdatee]
        },
        dataType: 'json',
        success: function(response) {
                    console.log(response);
                    swal('Data Terupdate', {
                        icon : "success",
                        buttons: {
                            confirm: {
                                className : 'btn btn-success'
                            }
                        },
                    }).then((Oke) => {
                        if (Oke) {
                            location.reload();
                        }
                    });
        },
        error: function(response) {
                    console.log(response);
                    swal('Gagal Terupdate', {
                        buttons: {
                            confirm: {
                                className : 'btn btn-warning'
                            }
                        },
                    }).then((Oke) => {
                        if (Oke) {
                            location.reload();
                        }
                    });
        }
    });
});