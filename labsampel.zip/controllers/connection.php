<?php
error_reporting(E_ALL^(E_NOTICE|E_WARNING));
// notakses();
function koneksi(){
    $koneksi=mysqli_connect("localhost","root","","db_sampel");
    //$koneksi=mysqli_connect("localhost","id8592240_epemilu321","crew321123","id8592240_epemilu");
    if (mysqli_connect_errno()){
        echo "Koneksi database gagal : " . mysqli_connect_error();
    }
    // notakses();
    return $koneksi;
}

function notakses(){
    session_start();
    ob_start();
    header( "HTTP/* 404 NOT FOUND" );
}

function root_base(){
    if ( (! empty($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] == 'https') ||
     (! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ||
     (! empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443') ) {
        if($_SERVER['SERVER_PORT'] != 80){
            return 'https://'.$_SERVER['SERVER_NAME'].':'.$_SERVER['SERVER_PORT'].'/labsampel/';
        }else{
            return 'https://'.$_SERVER['SERVER_NAME'].'/labsampel/';
        }
    } else {
        if($_SERVER['SERVER_PORT'] != 80){
            return 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER['SERVER_PORT'].'/labsampel/';
        }else{
            return 'http://'.$_SERVER['SERVER_NAME'].'/labsampel/';
        }
    }
}

$img_loc=$root_base."img/";
setlocale(LC_ALL,'id_ID');
function get_error(){
	$koneksi = $GLOBALS['koneksi'];
	$data = "<!DOCTYPE html>
        <html>
        <head>
            <title>Get Some Errors</title>
            
        </head>
        <body style='
        /* background: #ffd400; */
        text-align: center;
        font-size: 2em;
        color: #ffc800;'>
        <p>
        Situs ini mengalami beberapa masalah,
        Mohon maaf atas kedidaknyamanannya.
        :(
        </p>
        </body>
        </html>";
	return $data.$koneksi->error;
}
?>