<?php
@session_start();
require_once "connection.php"; 
ob_start();
// notakses();
if( isset ( $_POST[ 'login' ] ) && $_POST[ 'login' ] != NULL ) {
    print_r(login($_POST['username'],$_POST['password']));
}else{
    notakses();
}

function check_login($username){
    if(!is_null($username)){
        $qses =koneksi()->query("SELECT * FROM tbl_users where username='".$username."'")or die(get_error());
        $scan = mysqli_num_rows($qses);
        if ($scan == 1) {
            echo "<script>alert('Selamat Datang Kembali....,".$username."');window.location='".root_base()."views/index.php'</script> ";
        }else{
            logout();
        }
    }
}

function login($username,$password){
    $qa = mysqli_query(koneksi(),"SELECT * FROM tbl_users where username = '".$username."'AND password='" . md5($password) . "'")or die(get_error());
    $data   = mysqli_fetch_assoc($qa);
    $dataa = mysqli_num_rows($qa);
    if($dataa ==1){
        $_SESSION['username']=$username;
        echo "<script>alert('Selamat Datangg....,".$username."');window.location='".root_base()."views/index.php';</script> ";
    }
    else{
        $error=mysqli_error(koneksi());
        echo "<script>alert('Akun Anda Salah ".$error."');window.location='".root_base()."views/login.php';</script> ";
    }
}

function logout(){
    session_start();
    unset($_SESSION['username']);
    session_destroy();
    header('Location: '.root_base().'views/login.php');
}

function checkAndLevelUser($username){

    if(!is_null($username)){
        $qlevelUser = mysqli_query(koneksi(),"SELECT * FROM `tbl_users` INNER JOIN tbl_auth ON tbl_auth.id_auth = tbl_users.id_auth WHERE tbl_users.username = '".$username."'");
        $dataLevelUser = mysqli_fetch_assoc($qlevelUser);
        $tampungData = [];
        $tampungData = ['username'  => $dataLevelUser['username'],
                         'namauser' => $dataLevelUser['nama_users'],
                         'auth'     => $dataLevelUser['nama_auth'],
                         'id'     => $dataLevelUser['id_users'],
                        ];
        return $tampungData;
    }else{
        logout();
    }

}

function judulPage($page){
    return $page.'-page';
}

function menuHalaman($halaman){
    return 'Menu '.$halaman;
}
//print_r($qa);
// print_r($nim = $_POST['nama']);
// print_r($_SESSION);
// // session_start();
// unset($_SESSION['nama']);
// session_destroy();
?>