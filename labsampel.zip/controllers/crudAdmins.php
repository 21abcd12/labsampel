<?php
@session_start();
require_once "connection.php"; 
ob_start();
// notakses();

if(isset ( $_POST[ 'dataTambah' ] ) && $_POST[ 'dataTambah' ] != NULL){
    $username = $_POST["dataTambah"][0];
    $nama = $_POST["dataTambah"][1];
    $pass = $_POST["dataTambah"][2];
    // echo "key1 : ".$_POST["dataTambah"][0].$_POST["dataTambah"][1].$_POST["dataTambah"][2];
    $result = mysqli_query(koneksi(),"SELECT * FROM `tbl_users`WHERE tbl_users.username = '".$username."'");
    if ($result->num_rows > 0){
        echo 0;
    }else{
        $query = koneksi()->query( "INSERT INTO `tbl_users`(`id_auth`, `nama_users`, `username`,`password`) 
                                VALUES (1,'$nama','$username', '".md5($pass)."')" )or die( mysqli_error( $koneksi ) );
        echo 1;
    }
}else if(isset ( $_POST[ 'dataEdit' ] ) && $_POST[ 'dataEdit' ] != NULL) {
    // echo "key1 : ".$_POST["dataEdit"][0].$_POST["dataEdit"][1].$_POST["dataEdit"][2];
    $id = $_POST["dataEdit"][0];
    $nama = $_POST["dataEdit"][1];
    $pass = $_POST["dataEdit"][2];
    
    if($pass == NULL){
        koneksi()->query( "UPDATE tbl_users 
                            SET nama_users = '$nama' 
                            WHERE id_users = '".$id."'" )or die(mysqli_error(koneksi()));
        echo 1;
    }else{
        koneksi()->query( "UPDATE tbl_users 
                            SET nama_users = '$nama',password = '".md5($pass)."' 
                            WHERE id_users = '".$id."'" )or die(mysqli_error(koneksi()));
        echo 1;
    }
    
}else if(isset ( $_POST[ 'dataDelete' ] ) && $_POST[ 'dataDelete' ] != NULL){
	koneksi()->query("DELETE FROM tbl_users where id_users = '".$_POST[ 'dataDelete' ]."'")or die(mysqli_error(koneksi()));
    echo 1;
}else{
    // notakses();
}
function getall($id = NULL){
    if(is_null($id)){
        $result = mysqli_query(koneksi(),"SELECT * FROM `tbl_users` 
                                        INNER JOIN tbl_auth 
                                        ON tbl_auth.id_auth = tbl_users.id_auth 
                                        WHERE tbl_auth.nama_auth = 'admin'" );
        // $data = $qa->fetch_assoc();
        $tampung = array();
        if ($result->num_rows > 0){
            while($row = $result->fetch_assoc() ){
                // echo $row["username"] ."  " .$row["id_users"]. "<br>";
                $tampung[] = [
                    'id_users' => $row["id_users"],
                    'username' => $row["username"],
                    'password' => $row['password'],
                    'nama'=> $row['nama_users'],
                ];
            }
            } else {
                echo "Data Users Kosong";
            }
        return $tampung;
    }else{
        $result = mysqli_query(koneksi(),"SELECT * FROM `tbl_users` 
                                        INNER JOIN tbl_auth 
                                        ON tbl_auth.id_auth = tbl_users.id_auth 
                                        WHERE tbl_auth.nama_auth = 'admin' AND tbl_users.id_users =".$id)or die(mysqli_error(koneksi()));
        // $data = $qa->fetch_assoc();
        $tampung = array();
        if ($result->num_rows > 0){
            while($row = $result->fetch_assoc() ){
                // echo $row["username"] ."  " .$row["id_users"]. "<br>";
                $tampung = [
                    'id_users' => $row["id_users"],
                    'username' => $row["username"],
                    'password' => $row['password'],
                    'nama'=> $row['nama_users'],
                ];
            }
            } else {
                echo "0 records";
            }
        return $tampung;
    }
    
}
?>